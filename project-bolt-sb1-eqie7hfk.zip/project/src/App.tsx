import React, { useState } from 'react';
import { Header } from './components/Header';
import { Welcome } from './components/Welcome';
import { PreferenceForm } from './components/PreferenceForm';
import { Results } from './components/Results';
import { Comparison } from './components/Comparison';
import { AppState, UserPreferences } from './types';
import { NeighborhoodMatcher } from './algorithms/matching';
import { SAMPLE_NEIGHBORHOODS } from './data/neighborhoods';

function App() {
  const [state, setState] = useState<AppState>({
    step: 'welcome',
    preferences: null,
    matches: [],
    selectedNeighborhoods: [],
    loading: false
  });

  const matcher = new NeighborhoodMatcher();

  const handleStart = () => {
    setState(prev => ({ ...prev, step: 'preferences' }));
  };

  const handlePreferences = (preferences: UserPreferences) => {
    setState(prev => ({ ...prev, loading: true }));
    
    // Simulate API call delay
    setTimeout(() => {
      const matches = matcher.findMatches(preferences, SAMPLE_NEIGHBORHOODS);
      setState(prev => ({
        ...prev,
        preferences,
        matches,
        step: 'results',
        loading: false
      }));
    }, 1500);
  };

  const handleCompare = (selectedIds: string[]) => {
    setState(prev => ({
      ...prev,
      selectedNeighborhoods: selectedIds,
      step: 'comparison'
    }));
  };

  const handleBack = () => {
    if (state.step === 'comparison') {
      setState(prev => ({ ...prev, step: 'results' }));
    } else if (state.step === 'results') {
      setState(prev => ({ ...prev, step: 'preferences' }));
    } else if (state.step === 'preferences') {
      setState(prev => ({ ...prev, step: 'welcome' }));
    }
  };

  const showBackButton = state.step !== 'welcome';

  if (state.loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Analyzing Neighborhoods</h2>
          <p className="text-gray-600">Finding the perfect matches for your lifestyle...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header onBack={handleBack} showBackButton={showBackButton} />
      
      {state.step === 'welcome' && <Welcome onStart={handleStart} />}
      
      {state.step === 'preferences' && (
        <PreferenceForm onSubmit={handlePreferences} />
      )}
      
      {state.step === 'results' && (
        <Results matches={state.matches} onCompare={handleCompare} />
      )}
      
      {state.step === 'comparison' && (
        <Comparison 
          matches={state.matches}
          selectedIds={state.selectedNeighborhoods}
          onBack={handleBack}
        />
      )}
    </div>
  );
}

export default App;