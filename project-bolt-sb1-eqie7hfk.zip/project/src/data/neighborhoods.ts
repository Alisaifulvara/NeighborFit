import { Neighborhood } from '../types';

export const SAMPLE_NEIGHBORHOODS: Neighborhood[] = [
  {
    id: 'soma-sf',
    name: 'SoMa',
    city: 'San Francisco',
    state: 'CA',
    coordinates: { lat: 37.7749, lng: -122.4194 },
    demographics: {
      population: 35000,
      medianAge: 32,
      medianIncome: 95000,
      education: { highSchool: 85, college: 65, graduate: 25 }
    },
    housing: {
      medianRent: 3500,
      medianPrice: 1200000,
      rentGrowth: 0.05,
      priceGrowth: 0.03,
      inventory: 1200
    },
    lifestyle: {
      nightlife: 90,
      outdoors: 60,
      culture: 85,
      family: 40,
      dining: 95
    },
    amenities: {
      safety: 70,
      walkability: 95,
      transit: 90,
      schools: 60,
      costOfLiving: 30
    },
    commute: {
      toDowntown: 10,
      toAirport: 35,
      publicTransit: true
    }
  },
  {
    id: 'brooklyn-heights',
    name: 'Brooklyn Heights',
    city: 'New York',
    state: 'NY',
    coordinates: { lat: 40.6962, lng: -73.9969 },
    demographics: {
      population: 22000,
      medianAge: 38,
      medianIncome: 85000,
      education: { highSchool: 95, college: 75, graduate: 35 }
    },
    housing: {
      medianRent: 2800,
      medianPrice: 950000,
      rentGrowth: 0.04,
      priceGrowth: 0.02,
      inventory: 800
    },
    lifestyle: {
      nightlife: 75,
      outdoors: 70,
      culture: 90,
      family: 85,
      dining: 80
    },
    amenities: {
      safety: 85,
      walkability: 90,
      transit: 95,
      schools: 80,
      costOfLiving: 40
    },
    commute: {
      toDowntown: 15,
      toAirport: 45,
      publicTransit: true
    }
  },
  {
    id: 'austin-east',
    name: 'East Austin',
    city: 'Austin',
    state: 'TX',
    coordinates: { lat: 30.2672, lng: -97.7431 },
    demographics: {
      population: 45000,
      medianAge: 29,
      medianIncome: 55000,
      education: { highSchool: 80, college: 55, graduate: 20 }
    },
    housing: {
      medianRent: 1800,
      medianPrice: 450000,
      rentGrowth: 0.08,
      priceGrowth: 0.06,
      inventory: 2000
    },
    lifestyle: {
      nightlife: 85,
      outdoors: 80,
      culture: 75,
      family: 60,
      dining: 85
    },
    amenities: {
      safety: 75,
      walkability: 80,
      transit: 60,
      schools: 70,
      costOfLiving: 75
    },
    commute: {
      toDowntown: 20,
      toAirport: 25,
      publicTransit: false
    }
  },
  {
    id: 'capitol-hill-seattle',
    name: 'Capitol Hill',
    city: 'Seattle',
    state: 'WA',
    coordinates: { lat: 47.6205, lng: -122.3212 },
    demographics: {
      population: 30000,
      medianAge: 31,
      medianIncome: 70000,
      education: { highSchool: 90, college: 70, graduate: 30 }
    },
    housing: {
      medianRent: 2200,
      medianPrice: 650000,
      rentGrowth: 0.06,
      priceGrowth: 0.04,
      inventory: 1500
    },
    lifestyle: {
      nightlife: 95,
      outdoors: 85,
      culture: 80,
      family: 50,
      dining: 90
    },
    amenities: {
      safety: 80,
      walkability: 85,
      transit: 85,
      schools: 75,
      costOfLiving: 60
    },
    commute: {
      toDowntown: 15,
      toAirport: 30,
      publicTransit: true
    }
  },
  {
    id: 'highland-park-dallas',
    name: 'Highland Park',
    city: 'Dallas',
    state: 'TX',
    coordinates: { lat: 32.8338, lng: -96.7894 },
    demographics: {
      population: 8500,
      medianAge: 42,
      medianIncome: 150000,
      education: { highSchool: 98, college: 85, graduate: 45 }
    },
    housing: {
      medianRent: 2500,
      medianPrice: 850000,
      rentGrowth: 0.03,
      priceGrowth: 0.02,
      inventory: 300
    },
    lifestyle: {
      nightlife: 60,
      outdoors: 70,
      culture: 75,
      family: 95,
      dining: 85
    },
    amenities: {
      safety: 95,
      walkability: 70,
      transit: 40,
      schools: 95,
      costOfLiving: 25
    },
    commute: {
      toDowntown: 25,
      toAirport: 35,
      publicTransit: false
    }
  },
  {
    id: 'pearl-district-portland',
    name: 'Pearl District',
    city: 'Portland',
    state: 'OR',
    coordinates: { lat: 45.5262, lng: -122.6831 },
    demographics: {
      population: 15000,
      medianAge: 35,
      medianIncome: 65000,
      education: { highSchool: 92, college: 68, graduate: 28 }
    },
    housing: {
      medianRent: 1900,
      medianPrice: 520000,
      rentGrowth: 0.05,
      priceGrowth: 0.03,
      inventory: 900
    },
    lifestyle: {
      nightlife: 80,
      outdoors: 90,
      culture: 85,
      family: 70,
      dining: 90
    },
    amenities: {
      safety: 85,
      walkability: 95,
      transit: 90,
      schools: 80,
      costOfLiving: 70
    },
    commute: {
      toDowntown: 10,
      toAirport: 40,
      publicTransit: true
    }
  }
];