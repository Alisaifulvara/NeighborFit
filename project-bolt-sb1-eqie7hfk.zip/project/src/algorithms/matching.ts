import { UserPreferences, Neighborhood, NeighborhoodMatch } from '../types';

export class NeighborhoodMatcher {
  private normalizeScore(value: number, min: number, max: number): number {
    return Math.max(0, Math.min(100, ((value - min) / (max - min)) * 100));
  }

  private calculateBudgetScore(preferences: UserPreferences, neighborhood: Neighborhood): number {
    const rent = neighborhood.housing.medianRent;
    const { min, max } = preferences.budget;
    
    if (rent < min) return 60; // Below budget might indicate quality concerns
    if (rent > max) return Math.max(0, 100 - ((rent - max) / max) * 100);
    
    // Optimal range scoring
    const midpoint = (min + max) / 2;
    const distance = Math.abs(rent - midpoint);
    const range = (max - min) / 2;
    return Math.max(80, 100 - (distance / range) * 20);
  }

  private calculateLifestyleScore(preferences: UserPreferences, neighborhood: Neighborhood): number {
    const weights = preferences.lifestyle;
    const scores = neighborhood.lifestyle;
    
    let totalScore = 0;
    let totalWeight = 0;
    
    Object.entries(weights).forEach(([key, weight]) => {
      const score = scores[key as keyof typeof scores];
      totalScore += score * weight;
      totalWeight += weight;
    });
    
    return totalWeight > 0 ? totalScore / totalWeight : 0;
  }

  private calculateAmenitiesScore(preferences: UserPreferences, neighborhood: Neighborhood): number {
    const weights = preferences.priorities;
    const scores = neighborhood.amenities;
    
    let totalScore = 0;
    let totalWeight = 0;
    
    Object.entries(weights).forEach(([key, weight]) => {
      const score = scores[key as keyof typeof scores];
      totalScore += score * weight;
      totalWeight += weight;
    });
    
    return totalWeight > 0 ? totalScore / totalWeight : 0;
  }

  private calculateCommuteScore(preferences: UserPreferences, neighborhood: Neighborhood): number {
    const maxAcceptableCommute = preferences.commuteTime;
    const actualCommute = neighborhood.commute.toDowntown;
    
    if (actualCommute <= maxAcceptableCommute) {
      return 100 - (actualCommute / maxAcceptableCommute) * 30;
    } else {
      const overtime = actualCommute - maxAcceptableCommute;
      return Math.max(0, 70 - (overtime / maxAcceptableCommute) * 70);
    }
  }

  private generateInsights(
    preferences: UserPreferences,
    neighborhood: Neighborhood,
    breakdown: any
  ): { strengths: string[]; concerns: string[] } {
    const strengths: string[] = [];
    const concerns: string[] = [];
    
    // Budget analysis
    if (breakdown.budget > 80) {
      strengths.push('Excellent value for money');
    } else if (breakdown.budget < 50) {
      concerns.push('Above your budget range');
    }
    
    // Lifestyle analysis
    if (neighborhood.lifestyle.nightlife > 80 && preferences.lifestyle.nightlife > 7) {
      strengths.push('Vibrant nightlife scene');
    }
    if (neighborhood.lifestyle.outdoors > 80 && preferences.lifestyle.outdoors > 7) {
      strengths.push('Great outdoor activities');
    }
    if (neighborhood.lifestyle.family > 80 && preferences.lifestyle.family > 7) {
      strengths.push('Family-friendly environment');
    }
    
    // Amenities analysis
    if (neighborhood.amenities.safety > 85) {
      strengths.push('Very safe neighborhood');
    } else if (neighborhood.amenities.safety < 60) {
      concerns.push('Safety could be a concern');
    }
    
    if (neighborhood.amenities.walkability > 90) {
      strengths.push('Highly walkable');
    }
    
    if (neighborhood.amenities.transit > 85) {
      strengths.push('Excellent public transportation');
    }
    
    // Commute analysis
    if (breakdown.commute > 80) {
      strengths.push('Short commute to downtown');
    } else if (breakdown.commute < 50) {
      concerns.push('Longer commute time');
    }
    
    // Cost of living
    if (neighborhood.amenities.costOfLiving > 70) {
      strengths.push('Affordable cost of living');
    } else if (neighborhood.amenities.costOfLiving < 40) {
      concerns.push('High cost of living');
    }
    
    return { strengths, concerns };
  }

  public findMatches(preferences: UserPreferences, neighborhoods: Neighborhood[]): NeighborhoodMatch[] {
    const matches = neighborhoods.map(neighborhood => {
      const breakdown = {
        budget: this.calculateBudgetScore(preferences, neighborhood),
        lifestyle: this.calculateLifestyleScore(preferences, neighborhood),
        amenities: this.calculateAmenitiesScore(preferences, neighborhood),
        commute: this.calculateCommuteScore(preferences, neighborhood)
      };
      
      // Weighted overall score
      const score = (
        breakdown.budget * 0.25 +
        breakdown.lifestyle * 0.25 +
        breakdown.amenities * 0.35 +
        breakdown.commute * 0.15
      );
      
      const insights = this.generateInsights(preferences, neighborhood, breakdown);
      
      return {
        neighborhood,
        score,
        breakdown,
        ...insights
      };
    });
    
    return matches.sort((a, b) => b.score - a.score);
  }
}