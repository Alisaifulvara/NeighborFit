import React, { useState } from 'react';
import { UserPreferences } from '../types';
import { DollarSign, Clock, Star, Home } from 'lucide-react';

interface PreferenceFormProps {
  onSubmit: (preferences: UserPreferences) => void;
}

export const PreferenceForm: React.FC<PreferenceFormProps> = ({ onSubmit }) => {
  const [preferences, setPreferences] = useState<UserPreferences>({
    budget: { min: 1500, max: 3000 },
    commuteTime: 30,
    workLocation: 'downtown',
    lifestyle: {
      nightlife: 5,
      outdoors: 5,
      culture: 5,
      family: 5,
      dining: 5
    },
    priorities: {
      safety: 8,
      walkability: 6,
      transit: 6,
      schools: 5,
      costOfLiving: 7
    },
    housingType: 'any'
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(preferences);
  };

  const SliderInput = ({ 
    label, 
    value, 
    onChange, 
    min = 1, 
    max = 10, 
    description 
  }: {
    label: string;
    value: number;
    onChange: (value: number) => void;
    min?: number;
    max?: number;
    description?: string;
  }) => (
    <div className="space-y-2">
      <div className="flex justify-between items-center">
        <label className="text-sm font-medium text-gray-700">{label}</label>
        <span className="text-sm text-blue-600 font-semibold">{value}</span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        value={value}
        onChange={(e) => onChange(parseInt(e.target.value))}
        className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
      />
      {description && <p className="text-xs text-gray-500">{description}</p>}
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Tell Us About Your Preferences</h2>
          <p className="text-gray-600">
            Help us understand what matters most to you in a neighborhood
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Budget Section */}
          <div className="bg-white p-6 rounded-xl shadow-md">
            <div className="flex items-center space-x-2 mb-4">
              <DollarSign className="h-5 w-5 text-green-600" />
              <h3 className="text-lg font-semibold text-gray-900">Budget Range</h3>
            </div>
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Minimum Budget (Monthly)
                </label>
                <input
                  type="number"
                  value={preferences.budget.min}
                  onChange={(e) => setPreferences({
                    ...preferences,
                    budget: { ...preferences.budget, min: parseInt(e.target.value) }
                  })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  min="500"
                  step="100"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Maximum Budget (Monthly)
                </label>
                <input
                  type="number"
                  value={preferences.budget.max}
                  onChange={(e) => setPreferences({
                    ...preferences,
                    budget: { ...preferences.budget, max: parseInt(e.target.value) }
                  })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  min="500"
                  step="100"
                />
              </div>
            </div>
          </div>

          {/* Commute Section */}
          <div className="bg-white p-6 rounded-xl shadow-md">
            <div className="flex items-center space-x-2 mb-4">
              <Clock className="h-5 w-5 text-blue-600" />
              <h3 className="text-lg font-semibold text-gray-900">Commute Preferences</h3>
            </div>
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Work Location
                </label>
                <select
                  value={preferences.workLocation}
                  onChange={(e) => setPreferences({
                    ...preferences,
                    workLocation: e.target.value
                  })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="downtown">Downtown</option>
                  <option value="suburbs">Suburbs</option>
                  <option value="remote">Remote/Flexible</option>
                </select>
              </div>
              <div>
                <SliderInput
                  label="Maximum Commute Time (minutes)"
                  value={preferences.commuteTime}
                  onChange={(value) => setPreferences({
                    ...preferences,
                    commuteTime: value
                  })}
                  min={10}
                  max={90}
                />
              </div>
            </div>
          </div>

          {/* Lifestyle Section */}
          <div className="bg-white p-6 rounded-xl shadow-md">
            <div className="flex items-center space-x-2 mb-4">
              <Star className="h-5 w-5 text-purple-600" />
              <h3 className="text-lg font-semibold text-gray-900">Lifestyle Preferences</h3>
            </div>
            <div className="grid md:grid-cols-2 gap-6">
              <SliderInput
                label="Nightlife & Entertainment"
                value={preferences.lifestyle.nightlife}
                onChange={(value) => setPreferences({
                  ...preferences,
                  lifestyle: { ...preferences.lifestyle, nightlife: value }
                })}
                description="Bars, clubs, live music venues"
              />
              <SliderInput
                label="Outdoor Activities"
                value={preferences.lifestyle.outdoors}
                onChange={(value) => setPreferences({
                  ...preferences,
                  lifestyle: { ...preferences.lifestyle, outdoors: value }
                })}
                description="Parks, hiking, biking trails"
              />
              <SliderInput
                label="Culture & Arts"
                value={preferences.lifestyle.culture}
                onChange={(value) => setPreferences({
                  ...preferences,
                  lifestyle: { ...preferences.lifestyle, culture: value }
                })}
                description="Museums, theaters, galleries"
              />
              <SliderInput
                label="Family-Friendly"
                value={preferences.lifestyle.family}
                onChange={(value) => setPreferences({
                  ...preferences,
                  lifestyle: { ...preferences.lifestyle, family: value }
                })}
                description="Parks, family activities, quiet streets"
              />
              <SliderInput
                label="Dining Scene"
                value={preferences.lifestyle.dining}
                onChange={(value) => setPreferences({
                  ...preferences,
                  lifestyle: { ...preferences.lifestyle, dining: value }
                })}
                description="Restaurants, cafes, food variety"
              />
            </div>
          </div>

          {/* Priorities Section */}
          <div className="bg-white p-6 rounded-xl shadow-md">
            <div className="flex items-center space-x-2 mb-4">
              <Home className="h-5 w-5 text-orange-600" />
              <h3 className="text-lg font-semibold text-gray-900">Neighborhood Priorities</h3>
            </div>
            <div className="grid md:grid-cols-2 gap-6">
              <SliderInput
                label="Safety & Security"
                value={preferences.priorities.safety}
                onChange={(value) => setPreferences({
                  ...preferences,
                  priorities: { ...preferences.priorities, safety: value }
                })}
                description="Crime rates, lighting, security"
              />
              <SliderInput
                label="Walkability"
                value={preferences.priorities.walkability}
                onChange={(value) => setPreferences({
                  ...preferences,
                  priorities: { ...preferences.priorities, walkability: value }
                })}
                description="Walk Score, pedestrian-friendly"
              />
              <SliderInput
                label="Public Transit"
                value={preferences.priorities.transit}
                onChange={(value) => setPreferences({
                  ...preferences,
                  priorities: { ...preferences.priorities, transit: value }
                })}
                description="Bus, train, subway access"
              />
              <SliderInput
                label="School Quality"
                value={preferences.priorities.schools}
                onChange={(value) => setPreferences({
                  ...preferences,
                  priorities: { ...preferences.priorities, schools: value }
                })}
                description="Public school ratings"
              />
              <SliderInput
                label="Cost of Living"
                value={preferences.priorities.costOfLiving}
                onChange={(value) => setPreferences({
                  ...preferences,
                  priorities: { ...preferences.priorities, costOfLiving: value }
                })}
                description="Groceries, utilities, services"
              />
            </div>
          </div>

          {/* Housing Type */}
          <div className="bg-white p-6 rounded-xl shadow-md">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Housing Type Preference</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { value: 'apartment', label: 'Apartment' },
                { value: 'house', label: 'House' },
                { value: 'condo', label: 'Condo' },
                { value: 'any', label: 'Any Type' }
              ].map(option => (
                <label key={option.value} className="flex items-center space-x-2 cursor-pointer">
                  <input
                    type="radio"
                    name="housingType"
                    value={option.value}
                    checked={preferences.housingType === option.value}
                    onChange={(e) => setPreferences({
                      ...preferences,
                      housingType: e.target.value as any
                    })}
                    className="text-blue-600 focus:ring-blue-500"
                  />
                  <span className="text-sm font-medium text-gray-700">{option.label}</span>
                </label>
              ))}
            </div>
          </div>

          <div className="text-center">
            <button
              type="submit"
              className="bg-blue-600 text-white px-8 py-4 rounded-xl text-lg font-semibold hover:bg-blue-700 transform hover:scale-105 transition-all duration-200 shadow-lg hover:shadow-xl"
            >
              Find My Neighborhoods
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};