import React from 'react';
import { NeighborhoodMatch } from '../types';
import { MapPin, DollarSign, Clock, Star, ArrowLeft } from 'lucide-react';

interface ComparisonProps {
  matches: NeighborhoodMatch[];
  selectedIds: string[];
  onBack: () => void;
}

export const Comparison: React.FC<ComparisonProps> = ({ matches, selectedIds, onBack }) => {
  const selectedMatches = matches.filter(match => selectedIds.includes(match.neighborhood.id));

  const comparisonData = [
    { label: 'Match Score', key: 'score', format: (val: number) => `${Math.round(val)}%` },
    { label: 'Monthly Rent', key: 'housing.medianRent', format: (val: number) => `$${val.toLocaleString()}` },
    { label: 'Commute Time', key: 'commute.toDowntown', format: (val: number) => `${val} min` },
    { label: 'Population', key: 'demographics.population', format: (val: number) => val.toLocaleString() },
    { label: 'Median Income', key: 'demographics.medianIncome', format: (val: number) => `$${val.toLocaleString()}` },
    { label: 'Safety Score', key: 'amenities.safety', format: (val: number) => `${val}/100` },
    { label: 'Walkability', key: 'amenities.walkability', format: (val: number) => `${val}/100` },
    { label: 'Transit Score', key: 'amenities.transit', format: (val: number) => `${val}/100` }
  ];

  const getValue = (match: NeighborhoodMatch, key: string) => {
    if (key === 'score') return match.score;
    
    const keys = key.split('.');
    let value: any = match.neighborhood;
    for (const k of keys) {
      value = value?.[k];
    }
    return value;
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex items-center space-x-4 mb-8">
          <button
            onClick={onBack}
            className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <div>
            <h2 className="text-3xl font-bold text-gray-900">Neighborhood Comparison</h2>
            <p className="text-gray-600">Compare {selectedMatches.length} neighborhoods side by side</p>
          </div>
        </div>

        {/* Comparison Table */}
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Criteria
                  </th>
                  {selectedMatches.map(match => (
                    <th key={match.neighborhood.id} className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      <div className="space-y-1">
                        <div className="font-semibold text-gray-900 text-sm">{match.neighborhood.name}</div>
                        <div className="flex items-center space-x-1 text-xs text-gray-500">
                          <MapPin className="h-3 w-3" />
                          <span>{match.neighborhood.city}, {match.neighborhood.state}</span>
                        </div>
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {comparisonData.map((item, index) => (
                  <tr key={item.key} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      {item.label}
                    </td>
                    {selectedMatches.map(match => {
                      const value = getValue(match, item.key);
                      return (
                        <td key={match.neighborhood.id} className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {item.format(value)}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Score Breakdown */}
        <div className="mt-8 bg-white rounded-xl shadow-md p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-6">Match Score Breakdown</h3>
          <div className="grid gap-6">
            {['budget', 'lifestyle', 'amenities', 'commute'].map(category => (
              <div key={category} className="space-y-2">
                <h4 className="text-sm font-medium text-gray-700 capitalize">{category}</h4>
                <div className="grid gap-4" style={{ gridTemplateColumns: `200px repeat(${selectedMatches.length}, 1fr)` }}>
                  <div className="text-sm text-gray-500">Score</div>
                  {selectedMatches.map(match => (
                    <div key={match.neighborhood.id} className="space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium text-gray-900">
                          {Math.round(match.breakdown[category as keyof typeof match.breakdown])}%
                        </span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-blue-600 h-2 rounded-full" 
                          style={{ width: `${match.breakdown[category as keyof typeof match.breakdown]}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Strengths and Concerns */}
        <div className="mt-8 grid md:grid-cols-2 gap-6">
          <div className="bg-white rounded-xl shadow-md p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Strengths Comparison</h3>
            <div className="space-y-4">
              {selectedMatches.map(match => (
                <div key={match.neighborhood.id}>
                  <h4 className="font-medium text-gray-900 mb-2">{match.neighborhood.name}</h4>
                  <div className="space-y-1">
                    {match.strengths.slice(0, 3).map((strength, index) => (
                      <div key={index} className="text-sm text-green-700 bg-green-50 px-2 py-1 rounded">
                        {strength}
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-md p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Considerations</h3>
            <div className="space-y-4">
              {selectedMatches.map(match => (
                <div key={match.neighborhood.id}>
                  <h4 className="font-medium text-gray-900 mb-2">{match.neighborhood.name}</h4>
                  <div className="space-y-1">
                    {match.concerns.slice(0, 2).map((concern, index) => (
                      <div key={index} className="text-sm text-orange-700 bg-orange-50 px-2 py-1 rounded">
                        {concern}
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};