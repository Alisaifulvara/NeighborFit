import React from 'react';
import { NeighborhoodMatch } from '../types';
import { MapPin, DollarSign, Clock, Star, CheckCircle, AlertCircle } from 'lucide-react';

interface NeighborhoodCardProps {
  match: NeighborhoodMatch;
  onSelect: (id: string) => void;
  isSelected: boolean;
  onCompare: (id: string) => void;
}

export const NeighborhoodCard: React.FC<NeighborhoodCardProps> = ({ 
  match, 
  onSelect, 
  isSelected,
  onCompare 
}) => {
  const { neighborhood, score, breakdown, strengths, concerns } = match;

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600 bg-green-100';
    if (score >= 60) return 'text-yellow-600 bg-yellow-100';
    return 'text-red-600 bg-red-100';
  };

  const getScoreLabel = (score: number) => {
    if (score >= 80) return 'Excellent Match';
    if (score >= 60) return 'Good Match';
    return 'Fair Match';
  };

  return (
    <div className={`bg-white rounded-xl shadow-md hover:shadow-lg transition-all duration-200 ${
      isSelected ? 'ring-2 ring-blue-500' : ''
    }`}>
      <div className="p-6">
        {/* Header */}
        <div className="flex justify-between items-start mb-4">
          <div>
            <h3 className="text-xl font-bold text-gray-900">{neighborhood.name}</h3>
            <div className="flex items-center space-x-1 text-gray-600 mt-1">
              <MapPin className="h-4 w-4" />
              <span className="text-sm">{neighborhood.city}, {neighborhood.state}</span>
            </div>
          </div>
          <div className={`px-3 py-1 rounded-full text-sm font-semibold ${getScoreColor(score)}`}>
            {Math.round(score)}% Match
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          <div className="flex items-center space-x-2">
            <DollarSign className="h-4 w-4 text-green-600" />
            <div>
              <p className="text-sm text-gray-600">Median Rent</p>
              <p className="text-lg font-semibold text-gray-900">
                ${neighborhood.housing.medianRent.toLocaleString()}
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Clock className="h-4 w-4 text-blue-600" />
            <div>
              <p className="text-sm text-gray-600">Commute</p>
              <p className="text-lg font-semibold text-gray-900">
                {neighborhood.commute.toDowntown} min
              </p>
            </div>
          </div>
        </div>

        {/* Score Breakdown */}
        <div className="mb-6">
          <h4 className="text-sm font-semibold text-gray-900 mb-3">Match Breakdown</h4>
          <div className="space-y-2">
            {Object.entries(breakdown).map(([key, value]) => (
              <div key={key} className="flex items-center justify-between">
                <span className="text-sm text-gray-600 capitalize">
                  {key === 'costOfLiving' ? 'Cost of Living' : key}
                </span>
                <div className="flex items-center space-x-2">
                  <div className="w-16 bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-blue-600 h-2 rounded-full" 
                      style={{ width: `${value}%` }}
                    />
                  </div>
                  <span className="text-sm font-medium text-gray-900 w-8">
                    {Math.round(value)}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Strengths and Concerns */}
        <div className="space-y-4 mb-6">
          {strengths.length > 0 && (
            <div>
              <h4 className="text-sm font-semibold text-gray-900 mb-2 flex items-center space-x-1">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <span>Strengths</span>
              </h4>
              <div className="space-y-1">
                {strengths.slice(0, 3).map((strength, index) => (
                  <p key={index} className="text-sm text-green-700 bg-green-50 px-2 py-1 rounded">
                    {strength}
                  </p>
                ))}
              </div>
            </div>
          )}
          
          {concerns.length > 0 && (
            <div>
              <h4 className="text-sm font-semibold text-gray-900 mb-2 flex items-center space-x-1">
                <AlertCircle className="h-4 w-4 text-orange-600" />
                <span>Considerations</span>
              </h4>
              <div className="space-y-1">
                {concerns.slice(0, 2).map((concern, index) => (
                  <p key={index} className="text-sm text-orange-700 bg-orange-50 px-2 py-1 rounded">
                    {concern}
                  </p>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="flex space-x-3">
          <button
            onClick={() => onSelect(neighborhood.id)}
            className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors"
          >
            View Details
          </button>
          <button
            onClick={() => onCompare(neighborhood.id)}
            className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
          >
            Compare
          </button>
        </div>
      </div>
    </div>
  );
};