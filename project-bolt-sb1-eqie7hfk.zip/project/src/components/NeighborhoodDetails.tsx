import React from 'react';
import { NeighborhoodMatch } from '../types';
import { 
  MapPin, 
  DollarSign, 
  Users, 
  GraduationCap, 
  Clock,
  Shield,
  Bus,
  TreePine,
  Coffee,
  Star
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from 'recharts';

interface NeighborhoodDetailsProps {
  match: NeighborhoodMatch;
  onBack: () => void;
}

export const NeighborhoodDetails: React.FC<NeighborhoodDetailsProps> = ({ match, onBack }) => {
  const { neighborhood, score, breakdown, strengths, concerns } = match;

  const barData = [
    { name: 'Budget', score: breakdown.budget },
    { name: 'Lifestyle', score: breakdown.lifestyle },
    { name: 'Amenities', score: breakdown.amenities },
    { name: 'Commute', score: breakdown.commute }
  ];

  const radarData = [
    { subject: 'Safety', score: neighborhood.amenities.safety, fullMark: 100 },
    { subject: 'Walkability', score: neighborhood.amenities.walkability, fullMark: 100 },
    { subject: 'Transit', score: neighborhood.amenities.transit, fullMark: 100 },
    { subject: 'Schools', score: neighborhood.amenities.schools, fullMark: 100 },
    { subject: 'Cost of Living', score: neighborhood.amenities.costOfLiving, fullMark: 100 }
  ];

  const lifestyleData = [
    { name: 'Nightlife', score: neighborhood.lifestyle.nightlife },
    { name: 'Outdoors', score: neighborhood.lifestyle.outdoors },
    { name: 'Culture', score: neighborhood.lifestyle.culture },
    { name: 'Family', score: neighborhood.lifestyle.family },
    { name: 'Dining', score: neighborhood.lifestyle.dining }
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="bg-white rounded-xl shadow-md p-6 mb-8">
          <div className="flex justify-between items-start mb-6">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">{neighborhood.name}</h1>
              <div className="flex items-center space-x-2 text-gray-600">
                <MapPin className="h-5 w-5" />
                <span>{neighborhood.city}, {neighborhood.state}</span>
              </div>
            </div>
            <div className="text-right">
              <div className="text-3xl font-bold text-blue-600">{Math.round(score)}%</div>
              <div className="text-sm text-gray-600">Match Score</div>
            </div>
          </div>

          {/* Key Metrics */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="text-center">
              <DollarSign className="h-8 w-8 text-green-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-gray-900">
                ${neighborhood.housing.medianRent.toLocaleString()}
              </div>
              <div className="text-sm text-gray-600">Median Rent</div>
            </div>
            
            <div className="text-center">
              <Clock className="h-8 w-8 text-blue-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-gray-900">
                {neighborhood.commute.toDowntown} min
              </div>
              <div className="text-sm text-gray-600">Commute</div>
            </div>
            
            <div className="text-center">
              <Users className="h-8 w-8 text-purple-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-gray-900">
                {neighborhood.demographics.population.toLocaleString()}
              </div>
              <div className="text-sm text-gray-600">Population</div>
            </div>
            
            <div className="text-center">
              <Shield className="h-8 w-8 text-orange-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-gray-900">
                {neighborhood.amenities.safety}/100
              </div>
              <div className="text-sm text-gray-600">Safety Score</div>
            </div>
          </div>
        </div>

        {/* Insights */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          {strengths.length > 0 && (
            <div className="bg-white rounded-xl shadow-md p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center space-x-2">
                <Star className="h-5 w-5 text-green-600" />
                <span>Key Strengths</span>
              </h3>
              <div className="space-y-2">
                {strengths.map((strength, index) => (
                  <div key={index} className="flex items-start space-x-2">
                    <div className="w-2 h-2 bg-green-600 rounded-full mt-2 flex-shrink-0" />
                    <p className="text-gray-700">{strength}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          {concerns.length > 0 && (
            <div className="bg-white rounded-xl shadow-md p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center space-x-2">
                <Clock className="h-5 w-5 text-orange-600" />
                <span>Considerations</span>
              </h3>
              <div className="space-y-2">
                {concerns.map((concern, index) => (
                  <div key={index} className="flex items-start space-x-2">
                    <div className="w-2 h-2 bg-orange-600 rounded-full mt-2 flex-shrink-0" />
                    <p className="text-gray-700">{concern}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Charts */}
        <div className="grid lg:grid-cols-2 gap-6 mb-8">
          <div className="bg-white rounded-xl shadow-md p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Match Score Breakdown</h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={barData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis domain={[0, 100]} />
                <Tooltip />
                <Bar dataKey="score" fill="#2563EB" />
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="bg-white rounded-xl shadow-md p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Neighborhood Amenities</h3>
            <ResponsiveContainer width="100%" height={300}>
              <RadarChart data={radarData}>
                <PolarGrid />
                <PolarAngleAxis dataKey="subject" />
                <PolarRadiusAxis domain={[0, 100]} />
                <Radar name="Score" dataKey="score" stroke="#2563EB" fill="#2563EB" fillOpacity={0.6} />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Lifestyle Scores */}
        <div className="bg-white rounded-xl shadow-md p-6 mb-8">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Lifestyle Scores</h3>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={lifestyleData} layout="horizontal">
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis type="number" domain={[0, 100]} />
              <YAxis dataKey="name" type="category" />
              <Tooltip />
              <Bar dataKey="score" fill="#7C3AED" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Demographics */}
        <div className="bg-white rounded-xl shadow-md p-6 mb-8">
          <h3 className="text-lg font-semibold text-gray-900 mb-6">Demographics & Housing</h3>
          <div className="grid md:grid-cols-3 gap-6">
            <div>
              <h4 className="font-semibold text-gray-900 mb-3">Demographics</h4>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Median Age:</span>
                  <span className="font-medium">{neighborhood.demographics.medianAge}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Median Income:</span>
                  <span className="font-medium">${neighborhood.demographics.medianIncome.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">College Educated:</span>
                  <span className="font-medium">{neighborhood.demographics.education.college}%</span>
                </div>
              </div>
            </div>
            
            <div>
              <h4 className="font-semibold text-gray-900 mb-3">Housing Market</h4>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Median Price:</span>
                  <span className="font-medium">${neighborhood.housing.medianPrice.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Rent Growth:</span>
                  <span className="font-medium">{(neighborhood.housing.rentGrowth * 100).toFixed(1)}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Inventory:</span>
                  <span className="font-medium">{neighborhood.housing.inventory.toLocaleString()}</span>
                </div>
              </div>
            </div>
            
            <div>
              <h4 className="font-semibold text-gray-900 mb-3">Transportation</h4>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">To Downtown:</span>
                  <span className="font-medium">{neighborhood.commute.toDowntown} min</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">To Airport:</span>
                  <span className="font-medium">{neighborhood.commute.toAirport} min</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Public Transit:</span>
                  <span className="font-medium">{neighborhood.commute.publicTransit ? 'Yes' : 'No'}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Action Button */}
        <div className="text-center">
          <button
            onClick={onBack}
            className="bg-blue-600 text-white px-8 py-4 rounded-xl text-lg font-semibold hover:bg-blue-700 transition-colors"
          >
            Back to Results
          </button>
        </div>
      </div>
    </div>
  );
};