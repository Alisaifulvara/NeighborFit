import React, { useState } from 'react';
import { NeighborhoodMatch } from '../types';
import { NeighborhoodCard } from './NeighborhoodCard';
import { NeighborhoodDetails } from './NeighborhoodDetails';
import { Filter, SortAsc, MapPin } from 'lucide-react';

interface ResultsProps {
  matches: NeighborhoodMatch[];
  onCompare: (ids: string[]) => void;
}

export const Results: React.FC<ResultsProps> = ({ matches, onCompare }) => {
  const [selectedNeighborhood, setSelectedNeighborhood] = useState<string | null>(null);
  const [compareList, setCompareList] = useState<string[]>([]);
  const [sortBy, setSortBy] = useState<'score' | 'rent' | 'commute'>('score');
  const [filterBy, setFilterBy] = useState<'all' | 'budget' | 'commute'>('all');

  const selectedMatch = matches.find(m => m.neighborhood.id === selectedNeighborhood);

  const handleCompareToggle = (id: string) => {
    if (compareList.includes(id)) {
      setCompareList(compareList.filter(item => item !== id));
    } else if (compareList.length < 3) {
      setCompareList([...compareList, id]);
    }
  };

  const sortedMatches = [...matches].sort((a, b) => {
    switch (sortBy) {
      case 'rent':
        return a.neighborhood.housing.medianRent - b.neighborhood.housing.medianRent;
      case 'commute':
        return a.neighborhood.commute.toDowntown - b.neighborhood.commute.toDowntown;
      default:
        return b.score - a.score;
    }
  });

  const filteredMatches = sortedMatches.filter(match => {
    switch (filterBy) {
      case 'budget':
        return match.breakdown.budget > 70;
      case 'commute':
        return match.breakdown.commute > 70;
      default:
        return true;
    }
  });

  if (selectedMatch) {
    return (
      <NeighborhoodDetails 
        match={selectedMatch} 
        onBack={() => setSelectedNeighborhood(null)}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Your Neighborhood Matches
          </h2>
          <p className="text-gray-600 mb-6">
            Found {matches.length} neighborhoods that match your preferences
          </p>
          
          {/* Compare Button */}
          {compareList.length > 0 && (
            <button
              onClick={() => onCompare(compareList)}
              className="bg-purple-600 text-white px-6 py-3 rounded-lg hover:bg-purple-700 transition-colors mb-6"
            >
              Compare Selected ({compareList.length})
            </button>
          )}
        </div>

        {/* Controls */}
        <div className="flex flex-wrap gap-4 mb-8">
          <div className="flex items-center space-x-2">
            <SortAsc className="h-5 w-5 text-gray-600" />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="score">Sort by Match Score</option>
              <option value="rent">Sort by Rent (Low to High)</option>
              <option value="commute">Sort by Commute Time</option>
            </select>
          </div>
          
          <div className="flex items-center space-x-2">
            <Filter className="h-5 w-5 text-gray-600" />
            <select
              value={filterBy}
              onChange={(e) => setFilterBy(e.target.value as any)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="all">All Neighborhoods</option>
              <option value="budget">Budget-Friendly</option>
              <option value="commute">Short Commute</option>
            </select>
          </div>
        </div>

        {/* Results Grid */}
        <div className="grid lg:grid-cols-2 xl:grid-cols-3 gap-6">
          {filteredMatches.map((match) => (
            <NeighborhoodCard
              key={match.neighborhood.id}
              match={match}
              onSelect={setSelectedNeighborhood}
              isSelected={compareList.includes(match.neighborhood.id)}
              onCompare={handleCompareToggle}
            />
          ))}
        </div>

        {filteredMatches.length === 0 && (
          <div className="text-center py-12">
            <MapPin className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              No neighborhoods match your current filters
            </h3>
            <p className="text-gray-600">
              Try adjusting your filter criteria to see more results.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};