export interface UserPreferences {
  budget: {
    min: number;
    max: number;
  };
  commuteTime: number;
  workLocation: string;
  lifestyle: {
    nightlife: number;
    outdoors: number;
    culture: number;
    family: number;
    dining: number;
  };
  priorities: {
    safety: number;
    walkability: number;
    transit: number;
    schools: number;
    costOfLiving: number;
  };
  housingType: 'apartment' | 'house' | 'condo' | 'any';
}

export interface Neighborhood {
  id: string;
  name: string;
  city: string;
  state: string;
  coordinates: {
    lat: number;
    lng: number;
  };
  demographics: {
    population: number;
    medianAge: number;
    medianIncome: number;
    education: {
      highSchool: number;
      college: number;
      graduate: number;
    };
  };
  housing: {
    medianRent: number;
    medianPrice: number;
    rentGrowth: number;
    priceGrowth: number;
    inventory: number;
  };
  lifestyle: {
    nightlife: number;
    outdoors: number;
    culture: number;
    family: number;
    dining: number;
  };
  amenities: {
    safety: number;
    walkability: number;
    transit: number;
    schools: number;
    costOfLiving: number;
  };
  commute: {
    toDowntown: number;
    toAirport: number;
    publicTransit: boolean;
  };
}

export interface NeighborhoodMatch {
  neighborhood: Neighborhood;
  score: number;
  breakdown: {
    budget: number;
    lifestyle: number;
    amenities: number;
    commute: number;
  };
  strengths: string[];
  concerns: string[];
}

export interface AppState {
  step: 'welcome' | 'preferences' | 'results' | 'comparison';
  preferences: UserPreferences | null;
  matches: NeighborhoodMatch[];
  selectedNeighborhoods: string[];
  loading: boolean;
}